﻿//#### LAB 4 - FUNCTIONS ####
//PART 1:  PROGRAM ALERT FUNCTION


//################## CREATE YOUR FUNCTION




//################## TEST YOUR FUNCTION
