//#### LAB 5 - FUNCTIONS & OBJECTS ####
//PART 1:  I OBJECT!

